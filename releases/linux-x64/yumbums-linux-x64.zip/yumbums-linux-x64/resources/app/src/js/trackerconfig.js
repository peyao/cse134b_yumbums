window._trackJs = {
	token: 'ef8564d9e1f14812aed9643e6df23de0',
	application: 'yumbums',
	callback: {
		enabled: true,
		bindStack: true
	}
};
