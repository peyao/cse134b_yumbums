document.body.onload = function(){
    mixpanel.track('Page Loaded', {'Page Name': 'Welcome Page'});
}